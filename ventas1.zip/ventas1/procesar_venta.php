<?php
//Paso 1: Importar el archivo que se encargara de conectarme con la base de datos
require 'config/conex.php';

//Paso 2: capturar las 
$cantidad = $_POST["txt_cantidad"];
$total = 1500 * $cantidad;

//Paso 3: armar la sentencia SQL
$sql ="INSERT INTO ventas (valor) VALUES (".$total.")";

//Paso 4: Mandar la orden a la base de datos
if($dbh->query ($sql))
{
    //aparecera este mensaje 
    echo "Venta registrada: $".$total;
}else
{
    //Error aparece esto
    echo "Error en la venta";
}


?>